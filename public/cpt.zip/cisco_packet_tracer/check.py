def add(a, b):
    carry = 0
    summ = 0
    res = ""
    for i in range(len(a) - 1, -1, -1):
        summ = int(a[i]) + int(b[i]) + carry
        res = str(summ % 2) + res
        carry = summ // 2

    if carry == 0:
        return res
    else:
        temp = "00000001"
        return add(res, temp)


d = '10101011111100001011101110111101'

b1 = d[0:8]
b2 = d[8:16]
b3 = d[16:24]
b4 = d[24:32]

carry = 0

res = add(b1, b2)
res = add(res, b3)
res = add(res, b4)

check_sum = ''

# inversion
for i in res:
    if i == '1':
        check_sum += '0'
    else:
        check_sum += '1'

print(f"Check sum = {check_sum}")