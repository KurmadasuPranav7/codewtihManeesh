import random
data = [0,1,2,3,4,5,6,7]  

curr = 0
received_data = []

def receive(data):
    global curr
    print("Received:", data)
    received_data.append(data)
    curr = 1 - curr
    return
    
def send(data):
    global curr
    # con = input("Enter transmission condition: ")
    con = random.choice([True,False])
    while True:
        if con:
            print("Transmission Success...")
            data.append(curr)
            receive(data)
            break
        else:
            print("Transmission Failed, Resending...")
            send(data)
            break
           
for i in data:
    send([i])

print(received_data)