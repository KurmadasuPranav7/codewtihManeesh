data = input("Enter data: ")
flag = '$'
esc = 'R'
new_data = flag

for i in range(len(data)):
    if data[i] == flag or data[i] == esc:
        new_data += esc
    new_data += data[i]

new_data += flag

print(f"Given data: {data}")
print(f"Byte Stuffed data: {new_data}")