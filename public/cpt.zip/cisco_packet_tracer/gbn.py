import random

data = [0, 1, 2, 3, 4, 5, 6, 7]

w = 4
p = 0
next = 0
received_data = []


def receive(frame):
    print("Received:", frame)
    received_data.append(frame)


while p < len(data):
    print("Sending window:", data[p:p + w])
    next = p

    while next < p + w and next < len(data):
        success = random.choice([True, False])

        if success:
            print("Frame", data[next], "sent successfully")
            receive(data[next])
            next += 1
        else:
            print("Frame", data[next], "lost!")
            print("Go Back to Frame", data[p])
            break

    if next == p + w or next == len(data):
        p = next
    else:
        pass

print("Final Received Data:", received_data)