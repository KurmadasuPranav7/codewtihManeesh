d = '100100'
g = '1101'

curr_div = d[0:len(g)]
div = d + '0' * (len(g) - 1)


def xorr(a, b):
    res = ''

    for i in range(len(a)):
        res += str(int(a[i]) ^ int(b[i]))

    return res[1:]


temp = ''

for i in range(len(g), len(div)):
    if curr_div[0] == '1':
        temp = xorr(curr_div, g)
    else:
        temp = xorr(curr_div, "0" * len(g))

    temp += div[i]
    curr_div = temp

if curr_div[0] == '1':
    temp = xorr(curr_div, g)
else:
    temp = xorr(curr_div, "0" * len(g))

CRC = d + temp
print(f"Remainder = {temp}")
print(f"CRC = {CRC}")