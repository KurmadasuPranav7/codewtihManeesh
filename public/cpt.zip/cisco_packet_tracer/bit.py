data = '110101111101011111101011111110'
temp = 0
flag = '01111110'
new_data = flag + '  '

for i in range(len(data)):
    if data[i] == '0':
        temp = 0
    else:
        temp += 1
    if temp > 5:
        new_data += '0'
        temp = 0
    new_data += data[i]
new_data += '  ' + flag

print(f"Given data: {data}")
print(f"Byte Stuffed data: {new_data}")