d = '1010111'
parity = input('Enter parity code: ')
parity_bit = ''

cnt = d.count('1')

if parity in "eE":
    if cnt % 2 == 0:
        parity_bit = '0'
    else:
        parity_bit = '1'
else:
    if cnt % 2 == 0:
        parity_bit = '1'
    else:
        parity_bit = '0'

d = d + parity_bit
print(d)